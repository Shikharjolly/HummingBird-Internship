//  UserAuth.swift
//  hbcarrental.4900project

import Combine

class UserAuth: ObservableObject {
    @Published var isLoggedin = false
}
